void tapexit() {
  // 退出游戏
}
